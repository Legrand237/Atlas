# Étape 2b — Migrations Alembic, tables `users` et `audit_logs`

Ce que cette étape ajoute : l'outil de migrations (Alembic), la première migration `0001`, deux tables
(`users`, `audit_logs`) et une fonction `record_event` pour écrire dans l'audit.
Ce qu'elle n'ajoute PAS : mot de passe, connexion, routes d'authentification (étape 2c), autres tables.

Le journal `audit_logs` est « en ajout seul » : PostgreSQL lui-même refuse UPDATE, DELETE et TRUNCATE
(déclencheurs créés par la migration). Limite : le propriétaire de la base pourrait supprimer ces déclencheurs ;
une protection plus forte (un rôle de base qui n'a que le droit d'écrire) viendra avec la mise en production.

## A. Récupérer les fichiers (dans Codespaces, à la racine du dépôt)

1. Envoie `atlas-etape2b.zip` dans l'Explorateur (clic droit → Upload…).
2. Dans le terminal :

```bash
python3 -m zipfile -e atlas-etape2b.zip .
rm atlas-etape2b.zip
rm backend/app/db.py
```

La dernière ligne est NÉCESSAIRE : `db.py` est devenu le dossier `backend/app/db/` (même contenu, plus les modèles).
Le zip ne peut pas supprimer l'ancien fichier à ta place.

## B. Installer Alembic

```bash
cd backend
source .venv/bin/activate
pip install -r requirements-dev.txt
```

## C. Créer les tables dans ta base Neon

```bash
alembic upgrade head
alembic current
```

Résultat attendu : des lignes `Running upgrade  -> 0001, ...` puis, avec `alembic current`, `0001 (head)`.
Si tu vois `DatabaseNotConfigured` : `DATABASE_URL` est absente de `backend/.env`.
Pour vérifier dans Neon : console Neon → ton projet → « Tables » : `users`, `audit_logs`, `alembic_version`.

## D. Tests et contrôle qualité

```bash
pytest
ruff check . --output-format=concise
```

Résultat attendu (NON vérifié par l'auteur : à constater chez toi) : 71 tests réussis, 0 skipped
(34 déjà là + 37 nouveaux). Les 11 tests « sur base réelle » créent un schéma temporaire dans ta base Neon
(`test_atlas_...`), y appliquent les migrations, puis le suppriment : ta table `public` n'est pas touchée.
Si ces 11 tests apparaissent « skipped » : `DATABASE_URL` n'est pas lue (lance `pytest` depuis `backend/`).
Si une erreur parle de `search_path` ou `options` : ton adresse Neon est celle du « pooler » (hôte contenant
`-pooler`) ; reprends l'adresse de connexion directe.

## E. Vérifier ce qui sera enregistré, puis commit

```bash
cd ..
git status --short
```

Attendu : fichiers modifiés (`README.md`, `PROJECT_STATE.md`, `TODO.md`, `CHANGELOG.md`, `backend/requirements.txt`,
`backend/app/core/request_id.py`, `backend/tests/test_db.py`), `deleted: backend/app/db.py`, et des nouveaux fichiers
(`backend/alembic.ini`, `backend/app/db/`, deux fichiers de tests, ce guide). Ni `.env`, ni `.venv`, ni `.zip`.

## Ce qui n'est PAS fait à l'étape 2b
Colonne de mot de passe, hachage, connexion, tokens (2c) ; tables conversations, tasks, memories, etc. ;
extension pgvector ; écriture automatique d'audit depuis les requêtes HTTP (aucune route n'écrit encore dans l'audit).
